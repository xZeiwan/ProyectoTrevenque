<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProvinciaAemetSeeder extends Seeder
{
    public function run(): void
    {
        $provincias = [
            ['nombre' => 'Álava', 'codigo' => '01'],
            ['nombre' => 'Albacete', 'codigo' => '02'],
            ['nombre' => 'Alicante', 'codigo' => '03'],
            ['nombre' => 'Almería', 'codigo' => '04'],
            ['nombre' => 'Asturias', 'codigo' => '33'],
            ['nombre' => 'Ávila', 'codigo' => '05'],
            ['nombre' => 'Badajoz', 'codigo' => '06'],
            ['nombre' => 'Barcelona', 'codigo' => '08'],
            ['nombre' => 'Burgos', 'codigo' => '09'],
            ['nombre' => 'Cáceres', 'codigo' => '10'],
            ['nombre' => 'Cádiz', 'codigo' => '11'],
            ['nombre' => 'Cantabria', 'codigo' => '39'],
            ['nombre' => 'Castellón / Castelló', 'codigo' => '12'],
            ['nombre' => 'Ciudad Real', 'codigo' => '13'],
            ['nombre' => 'Córdoba', 'codigo' => '14'],
            ['nombre' => 'A Coruña', 'codigo' => '15'],
            ['nombre' => 'Cuenca', 'codigo' => '16'],
            ['nombre' => 'Girona', 'codigo' => '17'],
            ['nombre' => 'Granada', 'codigo' => '18'],
            ['nombre' => 'Guadalajara', 'codigo' => '19'],
            ['nombre' => 'Gipuzkoa', 'codigo' => '20'],
            ['nombre' => 'Huelva', 'codigo' => '21'],
            ['nombre' => 'Huesca', 'codigo' => '22'],
            ['nombre' => 'Illes Balears', 'codigo' => '07'],
            ['nombre' => 'Jaén', 'codigo' => '23'],
            ['nombre' => 'León', 'codigo' => '24'],
            ['nombre' => 'Lleida', 'codigo' => '25'],
            ['nombre' => 'La Rioja', 'codigo' => '26'],
            ['nombre' => 'Lugo', 'codigo' => '27'],
            ['nombre' => 'Madrid', 'codigo' => '28'],
            ['nombre' => 'Málaga', 'codigo' => '29'],
            ['nombre' => 'Murcia', 'codigo' => '30'],
            ['nombre' => 'Navarra', 'codigo' => '31'],
            ['nombre' => 'Ourense', 'codigo' => '32'],
            ['nombre' => 'Palencia', 'codigo' => '34'],
            ['nombre' => 'Las Palmas', 'codigo' => '35'],
            ['nombre' => 'Pontevedra', 'codigo' => '36'],
            ['nombre' => 'Salamanca', 'codigo' => '37'],
            ['nombre' => 'Santa Cruz de Tenerife', 'codigo' => '38'],
            ['nombre' => 'Segovia', 'codigo' => '40'],
            ['nombre' => 'Sevilla', 'codigo' => '41'],
            ['nombre' => 'Soria', 'codigo' => '42'],
            ['nombre' => 'Tarragona', 'codigo' => '43'],
            ['nombre' => 'Teruel', 'codigo' => '44'],
            ['nombre' => 'Toledo', 'codigo' => '45'],
            ['nombre' => 'Valencia', 'codigo' => '46'],
            ['nombre' => 'Valladolid', 'codigo' => '47'],
            ['nombre' => 'Bizkaia', 'codigo' => '48'],
            ['nombre' => 'Zamora', 'codigo' => '49'],
            ['nombre' => 'Zaragoza', 'codigo' => '50'],
            ['nombre' => 'Ceuta', 'codigo' => '51'],
            ['nombre' => 'Melilla', 'codigo' => '52'],
        ];

        DB::table('provinciasaemet')->truncate();
        DB::table('provinciasaemet')->insert($provincias);
    }
}
