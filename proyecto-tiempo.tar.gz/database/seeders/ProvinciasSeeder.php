<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProvinciasSeeder extends Seeder
{
    public function run(): void
    {
        // Asegurarse de que la tabla esté vacía antes de insertar
        DB::table('provincias')->truncate();
        DB::table('provincias')->insert([
            ['CODPROV' => '01', 'NOMBRE_PROVINCIA' => 'Álava', 'CODCOMUNIDAD' => '16'],
            ['CODPROV' => '02', 'NOMBRE_PROVINCIA' => 'Albacete', 'CODCOMUNIDAD' => '08'],
            ['CODPROV' => '03', 'NOMBRE_PROVINCIA' => 'Alicante', 'CODCOMUNIDAD' => '10'],
            ['CODPROV' => '04', 'NOMBRE_PROVINCIA' => 'Almería', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '05', 'NOMBRE_PROVINCIA' => 'Ávila', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '06', 'NOMBRE_PROVINCIA' => 'Badajoz', 'CODCOMUNIDAD' => '11'],
            ['CODPROV' => '07', 'NOMBRE_PROVINCIA' => 'Illes Balears', 'CODCOMUNIDAD' => '04'],
            ['CODPROV' => '08', 'NOMBRE_PROVINCIA' => 'Barcelona', 'CODCOMUNIDAD' => '09'],
            ['CODPROV' => '09', 'NOMBRE_PROVINCIA' => 'Burgos', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '10', 'NOMBRE_PROVINCIA' => 'Cáceres', 'CODCOMUNIDAD' => '11'],
            ['CODPROV' => '11', 'NOMBRE_PROVINCIA' => 'Cádiz', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '12', 'NOMBRE_PROVINCIA' => 'Castellón', 'CODCOMUNIDAD' => '10'],
            ['CODPROV' => '13', 'NOMBRE_PROVINCIA' => 'Ciudad Real', 'CODCOMUNIDAD' => '08'],
            ['CODPROV' => '14', 'NOMBRE_PROVINCIA' => 'Córdoba', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '15', 'NOMBRE_PROVINCIA' => 'A Coruña', 'CODCOMUNIDAD' => '12'],
            ['CODPROV' => '16', 'NOMBRE_PROVINCIA' => 'Cuenca', 'CODCOMUNIDAD' => '08'],
            ['CODPROV' => '17', 'NOMBRE_PROVINCIA' => 'Girona', 'CODCOMUNIDAD' => '09'],
            ['CODPROV' => '18', 'NOMBRE_PROVINCIA' => 'Granada', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '19', 'NOMBRE_PROVINCIA' => 'Guadalajara', 'CODCOMUNIDAD' => '08'],
            ['CODPROV' => '20', 'NOMBRE_PROVINCIA' => 'Gipuzkoa', 'CODCOMUNIDAD' => '16'],
            ['CODPROV' => '21', 'NOMBRE_PROVINCIA' => 'Huelva', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '22', 'NOMBRE_PROVINCIA' => 'Huesca', 'CODCOMUNIDAD' => '02'],
            ['CODPROV' => '23', 'NOMBRE_PROVINCIA' => 'Jaén', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '24', 'NOMBRE_PROVINCIA' => 'León', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '25', 'NOMBRE_PROVINCIA' => 'Lleida', 'CODCOMUNIDAD' => '09'],
            ['CODPROV' => '26', 'NOMBRE_PROVINCIA' => 'La Rioja', 'CODCOMUNIDAD' => '17'],
            ['CODPROV' => '27', 'NOMBRE_PROVINCIA' => 'Lugo', 'CODCOMUNIDAD' => '12'],
            ['CODPROV' => '28', 'NOMBRE_PROVINCIA' => 'Madrid', 'CODCOMUNIDAD' => '13'],
            ['CODPROV' => '29', 'NOMBRE_PROVINCIA' => 'Málaga', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '30', 'NOMBRE_PROVINCIA' => 'Murcia', 'CODCOMUNIDAD' => '14'],
            ['CODPROV' => '31', 'NOMBRE_PROVINCIA' => 'Navarra', 'CODCOMUNIDAD' => '15'],
            ['CODPROV' => '32', 'NOMBRE_PROVINCIA' => 'Ourense', 'CODCOMUNIDAD' => '12'],
            ['CODPROV' => '33', 'NOMBRE_PROVINCIA' => 'Asturias', 'CODCOMUNIDAD' => '03'],
            ['CODPROV' => '34', 'NOMBRE_PROVINCIA' => 'Palencia', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '35', 'NOMBRE_PROVINCIA' => 'Las Palmas', 'CODCOMUNIDAD' => '05'],
            ['CODPROV' => '36', 'NOMBRE_PROVINCIA' => 'Pontevedra', 'CODCOMUNIDAD' => '12'],
            ['CODPROV' => '37', 'NOMBRE_PROVINCIA' => 'Salamanca', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '38', 'NOMBRE_PROVINCIA' => 'Santa Cruz de Tenerife', 'CODCOMUNIDAD' => '05'],
            ['CODPROV' => '39', 'NOMBRE_PROVINCIA' => 'Cantabria', 'CODCOMUNIDAD' => '06'],
            ['CODPROV' => '40', 'NOMBRE_PROVINCIA' => 'Segovia', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '41', 'NOMBRE_PROVINCIA' => 'Sevilla', 'CODCOMUNIDAD' => '01'],
            ['CODPROV' => '42', 'NOMBRE_PROVINCIA' => 'Soria', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '43', 'NOMBRE_PROVINCIA' => 'Tarragona', 'CODCOMUNIDAD' => '09'],
            ['CODPROV' => '44', 'NOMBRE_PROVINCIA' => 'Teruel', 'CODCOMUNIDAD' => '02'],
            ['CODPROV' => '45', 'NOMBRE_PROVINCIA' => 'Toledo', 'CODCOMUNIDAD' => '08'],
            ['CODPROV' => '46', 'NOMBRE_PROVINCIA' => 'Valencia', 'CODCOMUNIDAD' => '10'],
            ['CODPROV' => '47', 'NOMBRE_PROVINCIA' => 'Valladolid', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '48', 'NOMBRE_PROVINCIA' => 'Bizkaia', 'CODCOMUNIDAD' => '16'],
            ['CODPROV' => '49', 'NOMBRE_PROVINCIA' => 'Zamora', 'CODCOMUNIDAD' => '07'],
            ['CODPROV' => '50', 'NOMBRE_PROVINCIA' => 'Zaragoza', 'CODCOMUNIDAD' => '02'],
            ['CODPROV' => '51', 'NOMBRE_PROVINCIA' => 'Ceuta', 'CODCOMUNIDAD' => '18'],
            ['CODPROV' => '52', 'NOMBRE_PROVINCIA' => 'Melilla', 'CODCOMUNIDAD' => '19'],
        ]);
    }
}
