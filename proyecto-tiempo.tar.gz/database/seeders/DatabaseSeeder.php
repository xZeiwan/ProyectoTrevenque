<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Solo insertar si la tabla provincias_aemet está vacía
        if (DB::table('provinciasaemet')->count() === 0) {
            $this->call(ProvinciaAemetSeeder::class);
        }

        // Solo insertar si la tabla municipiosaemet está vacía
        if (DB::table('municipiosaemet')->count() === 0) {
            $this->call(MunicipiosaemetSeeder::class);
        }

        // Solo insertar si la tabla comunidadautonoma está vacía
        if (DB::table('comunidadautonoma')->count() === 0) {
            $this->call(ComunidadAutonomaSeeder::class);
        }
        // Solo insertar si la tabla puntocontrol está vacía
        if (DB::table('puntocontrol')->count() === 0) {
            $this->call(PuntoControlSeeder::class);
        }

        // Puedes activar esto si necesitas usuarios fake
        // User::factory(10)->create();
    }
}
