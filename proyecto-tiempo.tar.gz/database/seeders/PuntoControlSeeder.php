<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PuntoControlSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('puntocontrol')->insert([
            ['provincia' => 'Almería', 'nombre' => 'Almería', 'latitud' => 36.834, 'longitud' => -2.463],
            ['provincia' => 'Cádiz', 'nombre' => 'Cádiz', 'latitud' => 36.529, 'longitud' => -6.292],
            ['provincia' => 'Córdoba', 'nombre' => 'Córdoba', 'latitud' => 37.888, 'longitud' => -4.779],
            ['provincia' => 'Granada', 'nombre' => 'Granada', 'latitud' => 37.176, 'longitud' => -3.598],
            ['provincia' => 'Huelva', 'nombre' => 'Huelva', 'latitud' => 37.261, 'longitud' => -6.944],
            ['provincia' => 'Jaén', 'nombre' => 'Jaén', 'latitud' => 37.769, 'longitud' => -3.790],
            ['provincia' => 'Málaga', 'nombre' => 'Málaga', 'latitud' => 36.720, 'longitud' => -4.420],
            ['provincia' => 'Sevilla', 'nombre' => 'Sevilla', 'latitud' => 37.388, 'longitud' => -5.982],
            ['provincia' => 'Huesca', 'nombre' => 'Huesca', 'latitud' => 42.140, 'longitud' => -0.408],
            ['provincia' => 'Teruel', 'nombre' => 'Teruel', 'latitud' => 40.344, 'longitud' => -1.106],
            ['provincia' => 'Zaragoza', 'nombre' => 'Zaragoza', 'latitud' => 41.648, 'longitud' => -0.889],
            ['provincia' => 'Asturias', 'nombre' => 'Oviedo', 'latitud' => 43.361, 'longitud' => -5.849],
            ['provincia' => 'Balears', 'nombre' => 'Palma', 'latitud' => 39.569, 'longitud' => 2.650],
            ['provincia' => 'Las Palmas', 'nombre' => 'Las Palmas de Gran Canaria', 'latitud' => 28.127, 'longitud' => -15.431],
            ['provincia' => 'Santa Cruz de Tenerife', 'nombre' => 'Santa Cruz de Tenerife', 'latitud' => 28.463, 'longitud' => -16.251],
            ['provincia' => 'Cantabria', 'nombre' => 'Santander', 'latitud' => 43.462, 'longitud' => -3.810],
            ['provincia' => 'Ávila', 'nombre' => 'Ávila', 'latitud' => 40.657, 'longitud' => -4.681],
            ['provincia' => 'Burgos', 'nombre' => 'Burgos', 'latitud' => 42.343, 'longitud' => -3.696],
            ['provincia' => 'León', 'nombre' => 'León', 'latitud' => 42.598, 'longitud' => -5.567],
            ['provincia' => 'Palencia', 'nombre' => 'Palencia', 'latitud' => 42.010, 'longitud' => -4.532],
            ['provincia' => 'Salamanca', 'nombre' => 'Salamanca', 'latitud' => 40.965, 'longitud' => -5.664],
            ['provincia' => 'Segovia', 'nombre' => 'Segovia', 'latitud' => 40.942, 'longitud' => -4.108],
            ['provincia' => 'Soria', 'nombre' => 'Soria', 'latitud' => 41.766, 'longitud' => -2.468],
            ['provincia' => 'Valladolid', 'nombre' => 'Valladolid', 'latitud' => 41.652, 'longitud' => -4.724],
            ['provincia' => 'Zamora', 'nombre' => 'Zamora', 'latitud' => 41.503, 'longitud' => -5.744],
            ['provincia' => 'Albacete', 'nombre' => 'Albacete', 'latitud' => 38.995, 'longitud' => -1.855],
            ['provincia' => 'Ciudad Real', 'nombre' => 'Ciudad Real', 'latitud' => 38.986, 'longitud' => -3.928],
            ['provincia' => 'Cuenca', 'nombre' => 'Cuenca', 'latitud' => 40.070, 'longitud' => -2.137],
            ['provincia' => 'Guadalajara', 'nombre' => 'Guadalajara', 'latitud' => 40.633, 'longitud' => -3.167],
            ['provincia' => 'Toledo', 'nombre' => 'Toledo', 'latitud' => 39.862, 'longitud' => -4.027],
            ['provincia' => 'Barcelona', 'nombre' => 'Barcelona', 'latitud' => 41.387, 'longitud' => 2.168],
            ['provincia' => 'Girona', 'nombre' => 'Girona', 'latitud' => 41.979, 'longitud' => 2.821],
            ['provincia' => 'Lleida', 'nombre' => 'Lleida', 'latitud' => 41.617, 'longitud' => 0.620],
            ['provincia' => 'Tarragona', 'nombre' => 'Tarragona', 'latitud' => 41.117, 'longitud' => 1.245],
            ['provincia' => 'Alicante', 'nombre' => 'Alicante', 'latitud' => 38.346, 'longitud' => -0.490],
            ['provincia' => 'Castellón', 'nombre' => 'Castelló de la Plana', 'latitud' => 39.986, 'longitud' => -0.036],
            ['provincia' => 'Valencia', 'nombre' => 'València', 'latitud' => 39.469, 'longitud' => -0.376],
            ['provincia' => 'Badajoz', 'nombre' => 'Badajoz', 'latitud' => 38.879, 'longitud' => -6.970],
            ['provincia' => 'Cáceres', 'nombre' => 'Cáceres', 'latitud' => 39.475, 'longitud' => -6.372],
            ['provincia' => 'Coruña', 'nombre' => 'A Coruña', 'latitud' => 43.362, 'longitud' => -8.411],
            ['provincia' => 'Lugo', 'nombre' => 'Lugo', 'latitud' => 43.013, 'longitud' => -7.556],
            ['provincia' => 'Ourense', 'nombre' => 'Ourense', 'latitud' => 42.335, 'longitud' => -7.863],
            ['provincia' => 'Pontevedra', 'nombre' => 'Pontevedra', 'latitud' => 42.433, 'longitud' => -8.644],
            ['provincia' => 'Madrid', 'nombre' => 'Madrid', 'latitud' => 40.416, 'longitud' => -3.703],
            ['provincia' => 'Murcia', 'nombre' => 'Murcia', 'latitud' => 37.987, 'longitud' => -1.130],
            ['provincia' => 'Navarra', 'nombre' => 'Pamplona', 'latitud' => 42.817, 'longitud' => -1.644],
            ['provincia' => 'Álava', 'nombre' => 'Vitoria-Gasteiz', 'latitud' => 42.846, 'longitud' => -2.671],
            ['provincia' => 'Bizkaia', 'nombre' => 'Bilbao', 'latitud' => 43.263, 'longitud' => -2.935],
            ['provincia' => 'Gipuzkoa', 'nombre' => 'Donostia/San Sebastián', 'latitud' => 43.322, 'longitud' => -1.985],
            ['provincia' => 'La Rioja', 'nombre' => 'Logroño', 'latitud' => 42.466, 'longitud' => -2.445],
            ['provincia' => 'Ceuta', 'nombre' => 'Ceuta', 'latitud' => 35.888, 'longitud' => -5.316],
            ['provincia' => 'Melilla', 'nombre' => 'Melilla', 'latitud' => 35.292, 'longitud' => -2.938],
        ]);
    }
}
