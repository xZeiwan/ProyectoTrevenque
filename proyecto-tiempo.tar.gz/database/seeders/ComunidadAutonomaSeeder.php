<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ComunidadAutonomaSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('comunidadautonoma')->insert([
            ['CODIGO' => '01', 'NOMBRE' => 'Andalucía'],
            ['CODIGO' => '02', 'NOMBRE' => 'Aragón'],
            ['CODIGO' => '03', 'NOMBRE' => 'Asturias'],
            ['CODIGO' => '04', 'NOMBRE' => 'Baleares'],
            ['CODIGO' => '05', 'NOMBRE' => 'Canarias'],
            ['CODIGO' => '06', 'NOMBRE' => 'Cantabria'],
            ['CODIGO' => '07', 'NOMBRE' => 'Castilla y León'],
            ['CODIGO' => '08', 'NOMBRE' => 'Castilla-La Mancha'],
            ['CODIGO' => '09', 'NOMBRE' => 'Cataluña'],
            ['CODIGO' => '10', 'NOMBRE' => 'Comunidad Valenciana'],
            ['CODIGO' => '11', 'NOMBRE' => 'Extremadura'],
            ['CODIGO' => '12', 'NOMBRE' => 'Galicia'],
            ['CODIGO' => '13', 'NOMBRE' => 'Madrid'],
            ['CODIGO' => '14', 'NOMBRE' => 'Murcia'],
            ['CODIGO' => '15', 'NOMBRE' => 'Navarra'],
            ['CODIGO' => '16', 'NOMBRE' => 'País Vasco'],
            ['CODIGO' => '17', 'NOMBRE' => 'La Rioja'],
            ['CODIGO' => '18', 'NOMBRE' => 'Ceuta'],
            ['CODIGO' => '19', 'NOMBRE' => 'Melilla'],
        ]);
    }
}
