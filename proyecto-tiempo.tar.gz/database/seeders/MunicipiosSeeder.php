<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MunicipiosSeeder extends Seeder
{
    public function run(): void
    {
        $file = storage_path('app/municipios_ine_limpio.csv');

        if (!file_exists($file)) {
            $this->command->error("El archivo CSV no existe en: $file");
            return;
        }

        $handle = fopen($file, 'r');
        $header = fgetcsv($handle); // leer la cabecera

        if ($header !== ['codigo_ine', 'nombre']) {
            $this->command->error("Cabecera inválida en CSV");
            fclose($handle);
            return;
        }

        $count = 0;

        while (($data = fgetcsv($handle)) !== false) {
            if (count($data) !== 2) continue;

            DB::table('municipios')->insert([
                'CODIGOINE' => $data[0],
                'CODPROV'   => substr($data[0], 0, 2),
                'CODMUN'    => substr($data[0], 2, 3),
                'NOMBRE'    => $data[1],
            ]);
            $count++;
        }

        fclose($handle);
        $this->command->info("Se han insertado $count municipios.");
    }
}
