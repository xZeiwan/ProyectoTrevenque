<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class MunicipiosaemetSeeder extends Seeder
{
    public function run(): void
    {
        $filePath = storage_path('app/datos.csv');
        $file = fopen($filePath, 'r');

        $insertados = 0;

        // Leer cabecera
        $headers = fgetcsv($file);

        while (($data = fgetcsv($file)) !== false) {
            if (count($data) !== 6) {
                continue; // saltar filas con columnas mal formadas
            }

            // Insertar si no existe ya
            DB::table('municipiosaemet')->updateOrInsert(
                ['codigo_municipio' => $data[5]],
                [
                    'CODAUTO' => $data[0],
                    'CPRO' => $data[1],
                    'CMUN' => $data[2],
                    'DC' => $data[3],
                    'NOMBRE' => $data[4],
                ]
            );

            $insertados++;
        }

        fclose($file);
        $this->command->info("Se han insertado o actualizado $insertados municipios.");
    }
}
