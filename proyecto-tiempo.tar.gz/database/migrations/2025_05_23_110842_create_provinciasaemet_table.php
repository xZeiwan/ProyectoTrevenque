<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('provinciasaemet', function (Blueprint $table) {
            $table->id();
            $table->string('CODIGO'); // Código oficial AEMET (ej. 01, 02, 071...)
            $table->string('NOMBRE'); // Nombre de la provincia en AEMET
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provinciasaemet');
    }
};
