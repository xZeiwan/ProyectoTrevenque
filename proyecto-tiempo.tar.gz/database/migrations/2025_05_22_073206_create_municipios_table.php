<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('municipios', function (Blueprint $table) {
            $table->id();
            $table->string('CODIGOINE')->unique();
            $table->string('CODPROV', 2);
            $table->string('CODMUN', 3);
            $table->string('NOMBRE');
            $table->timestamps();

            $table->unique(['CODPROV', 'CODMUN']);
            $table->index('NOMBRE');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('municipios');
    }
};
