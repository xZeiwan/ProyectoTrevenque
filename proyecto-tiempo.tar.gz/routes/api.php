<?php
// ==================== IMPORTS elTiempo.net ====================
use App\Http\Controllers\TiempoNetController;
use App\Http\Controllers\ProvinciaController;
use App\Http\Controllers\TiempoComunidadController;

// ==================== IMPORTS AEMET ====================
use App\Http\Controllers\AemetController;
use App\Http\Controllers\AemetMunicipioController;
use App\Http\Controllers\AemetProvinciaController;
use Illuminate\Support\Facades\DB;

// ==================== IMPORTS DATOS ESTADÍSTICOS GLOBALES ====================
use App\Http\Controllers\AemetEstadisticasController;

// ==================== IMPORTS PUNTOS CONTROL MAPA ====================
use App\Models\PuntoControl;
use Illuminate\Support\Facades\Http;
use App\Http\Controllers\MapaController;

// ==================== RUTAS elTiempo.net ====================
Route::get('/tiempo/{codprov}', [TiempoNetController::class, 'datosProvincia']);
Route::get('/municipios/{nombreProvincia}', [TiempoNetController::class, 'municipiosPorProvincia']);
Route::get('/tiempo-municipio/{codprov}/{codigoine}', [TiempoNetController::class, 'datosMunicipio']);
Route::get('/comunidades', [TiempoComunidadController::class, 'listar']);
Route::get('/tiempo-comunidad/{codigo}', [TiempoComunidadController::class, 'tiempoComunidad']);
Route::get('/provincias', [ProvinciaController::class, 'index']);

// ==================== RUTAS AEMET ====================
Route::get('/aemet/provincias', [AemetProvinciaController::class, 'index']);
Route::get('/aemet/provincia/{codigo}', [AemetProvinciaController::class, 'consultarPorCodigo']); // <-- Añade esta línea
Route::get('/aemet/municipio/{codigo}', [AemetMunicipioController::class, 'consultarPorCodigo']);

// Listado de municipios AEMET para select
Route::get('/municipios-aemet', function () {
    return DB::table('municipiosaemet')
        ->selectRaw('codigo_municipio as codigo, NOMBRE')
        ->whereNotNull('codigo_municipio')
        ->where('codigo_municipio', 'REGEXP', '^[0-9]{5}$') // solo códigos válidos
        ->orderBy('NOMBRE')
        ->get();
});

// Listado de comunidades autónomas AEMET
Route::get('/aemet/comunidades', function () {
    return DB::table('comunidadautonomaaemet')
        ->select('id', 'CODIGO as codigo', 'NOMBRE as nombre')
        ->orderBy('NOMBRE')
        ->get();
});

// Provincias de una comunidad autónoma AEMET
Route::get('/aemet/comunidad/{codigo}/provincias', function ($codigo) {
    $comunidad = DB::table('comunidadautonomaaemet')->where('CODIGO', $codigo)->first();
    if (!$comunidad) {
        return response()->json(['error' => 'Comunidad no encontrada'], 404);
    }
    return DB::table('provinciasaemet')
        ->where('comunidad_id', $comunidad->id)
        ->select('NOMBRE as nombre', 'CODIGO as codigo')
        ->orderBy('NOMBRE')
        ->get();
});

// ===================== RUTAS DATOS ESTADÍSTICOS GLOBALES AEMET ====================
Route::get('/aemet/estadisticas/diarias/{fechaIni}/{fechaFin}', [AemetEstadisticasController::class, 'diariasGlobales']);

// ==================== RUTAS PUNTOS DE CONTROL MAPA ====================
Route::get('/puntos-control', [MapaController::class, 'listarPuntos']);
Route::get('/puntos-control/{id}/tiempo-provincia', [MapaController::class, 'tiempoProvinciaPunto']);
Route::get('/puntos-control', function () {
    return PuntoControl::select('id', 'nombre', 'latitud', 'longitud', 'provincia')
        ->whereNotNull('latitud')
        ->whereNotNull('longitud')
        ->get();
});

//Enlazar eltiempo.net con puntos de control
Route::get('/puntos-control/{id}/tiempo-eltiempo', function ($id) {
    $punto = PuntoControl::find($id);
    if (!$punto) return response()->json(['error' => 'No encontrado'], 404);

    $provincia = $punto->provincia;

    if (!$provincia) {
        return response()->json(['error' => 'Provincia no especificada'], 400);
    }

    try {
        $res = Http::get("http://192.168.56.101:8000/api/tiempo/" . urlencode($provincia));
        if (!$res->ok()) {
            return response()->json(['error' => 'No se pudo obtener datos de Eltiempo.net'], 500);
        }

        $datos = $res->json();
        $ciudad = collect($datos['ciudades'])->firstWhere('name', $datos['provincia']['CAPITAL_PROVINCIA']);

        if (!$ciudad) {
            return response()->json(['error' => 'Ciudad no encontrada'], 404);
        }

        return [
            'ciudad' => $ciudad['name'],
            'descripcion' => $ciudad['stateSky']['description'] ?? 'Sin datos',
            'temperatura_max' => $ciudad['temperatures']['max'] ?? null,
            'temperatura_min' => $ciudad['temperatures']['min'] ?? null,
        ];
    } catch (\Throwable $e) {
        return response()->json(['error' => 'Error de servidor'], 500);
    }
});