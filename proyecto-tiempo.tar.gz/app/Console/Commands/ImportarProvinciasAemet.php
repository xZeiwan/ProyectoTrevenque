<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ImportarProvinciasAemet extends Command
{
    protected $signature = 'importar:provinciasaemet';
    protected $description = 'Importa las provincias compatibles con la API de AEMET';

    public function handle()
    {
        $provincias = [
            ['codigo' => '01', 'nombre' => 'Araba/Álava'],
            ['codigo' => '02', 'nombre' => 'Albacete'],
            ['codigo' => '03', 'nombre' => 'Alacant/Alicante'],
            ['codigo' => '04', 'nombre' => 'Almería'],
            ['codigo' => '05', 'nombre' => 'Ávila'],
            ['codigo' => '06', 'nombre' => 'Badajoz'],
            ['codigo' => '07', 'nombre' => 'Illes Balears'],
            ['codigo' => '08', 'nombre' => 'Barcelona'],
            ['codigo' => '09', 'nombre' => 'Burgos'],
            ['codigo' => '10', 'nombre' => 'Cáceres'],
            ['codigo' => '11', 'nombre' => 'Cádiz'],
            ['codigo' => '12', 'nombre' => 'Castelló/Castellón'],
            ['codigo' => '13', 'nombre' => 'Ciudad Real'],
            ['codigo' => '14', 'nombre' => 'Córdoba'],
            ['codigo' => '15', 'nombre' => 'A Coruña'],
            ['codigo' => '16', 'nombre' => 'Cuenca'],
            ['codigo' => '17', 'nombre' => 'Girona'],
            ['codigo' => '18', 'nombre' => 'Granada'],
            ['codigo' => '19', 'nombre' => 'Guadalajara'],
            ['codigo' => '20', 'nombre' => 'Gipuzkoa'],
            ['codigo' => '21', 'nombre' => 'Huelva'],
            ['codigo' => '22', 'nombre' => 'Huesca'],
            ['codigo' => '23', 'nombre' => 'Jaén'],
            ['codigo' => '24', 'nombre' => 'León'],
            ['codigo' => '25', 'nombre' => 'Lleida'],
            ['codigo' => '26', 'nombre' => 'La Rioja'],
            ['codigo' => '27', 'nombre' => 'Lugo'],
            ['codigo' => '28', 'nombre' => 'Madrid'],
            ['codigo' => '29', 'nombre' => 'Málaga'],
            ['codigo' => '30', 'nombre' => 'Murcia'],
            ['codigo' => '31', 'nombre' => 'Navarra'],
            ['codigo' => '32', 'nombre' => 'Ourense'],
            ['codigo' => '33', 'nombre' => 'Asturias'],
            ['codigo' => '34', 'nombre' => 'Palencia'],
            ['codigo' => '35', 'nombre' => 'Las Palmas'],
            ['codigo' => '36', 'nombre' => 'Pontevedra'],
            ['codigo' => '37', 'nombre' => 'Salamanca'],
            ['codigo' => '38', 'nombre' => 'Santa Cruz de Tenerife'],
            ['codigo' => '39', 'nombre' => 'Cantabria'],
            ['codigo' => '40', 'nombre' => 'Segovia'],
            ['codigo' => '41', 'nombre' => 'Sevilla'],
            ['codigo' => '42', 'nombre' => 'Soria'],
            ['codigo' => '43', 'nombre' => 'Tarragona'],
            ['codigo' => '44', 'nombre' => 'Teruel'],
            ['codigo' => '45', 'nombre' => 'Toledo'],
            ['codigo' => '46', 'nombre' => 'València/Valencia'],
            ['codigo' => '47', 'nombre' => 'Valladolid'],
            ['codigo' => '48', 'nombre' => 'Bizkaia'],
            ['codigo' => '49', 'nombre' => 'Zamora'],
            ['codigo' => '50', 'nombre' => 'Zaragoza'],
            ['codigo' => '51', 'nombre' => 'Ceuta'],
            ['codigo' => '52', 'nombre' => 'Melilla'],
            ['codigo' => '071', 'nombre' => 'Isla de Menorca'],
            ['codigo' => '072', 'nombre' => 'Isla de Mallorca'],
            ['codigo' => '073', 'nombre' => 'Islas de Ibiza y Formentera'],
            ['codigo' => '351', 'nombre' => 'Isla de Lanzarote'],
            ['codigo' => '352', 'nombre' => 'Isla de Fuerteventura'],
            ['codigo' => '353', 'nombre' => 'Isla de Gran Canaria'],
            ['codigo' => '381', 'nombre' => 'Isla de Tenerife'],
            ['codigo' => '382', 'nombre' => 'Isla de La Gomera'],
            ['codigo' => '383', 'nombre' => 'Isla de La Palma'],
            ['codigo' => '384', 'nombre' => 'Isla de El Hierro'],
        ];

        foreach ($provincias as $provincia) {
            DB::table('provinciasaemet')->updateOrInsert(
                ['codigo' => $provincia['codigo']],
                ['nombre' => $provincia['nombre']]
            );
        }

        $this->info("Provincias de AEMET insertadas correctamente.");
    }
}
