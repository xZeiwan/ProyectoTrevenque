<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AemetEstadisticasController extends Controller
{
    public function diariasGlobales($fechaIni, $fechaFin)
    {
        $apiKey = env('AEMET_API_KEY');

        // Convierte fechas de 20240301 a 2024-03-01T00:00:00UTC
        $fechaIniFmt = substr($fechaIni,0,4) . '-' . substr($fechaIni,4,2) . '-' . substr($fechaIni,6,2) . 'T00:00:00UTC';
        $fechaFinFmt = substr($fechaFin,0,4) . '-' . substr($fechaFin,4,2) . '-' . substr($fechaFin,6,2) . 'T00:00:00UTC';

        $url = "https://opendata.aemet.es/opendata/api/valores/climatologicos/diarios/datos/fechaini/$fechaIniFmt/fechafin/$fechaFinFmt/todasestaciones";
        $response = Http::withHeaders(['api_key' => $apiKey])->get($url);
        $json = $response->json();
        if (!isset($json['datos'])) {
            return response()->json(['error' => 'No se pudo obtener el enlace de datos'], 500);
        }
        $datosUrl = $json['datos'];
        $datosResponse = Http::get($datosUrl);
        $csv = $datosResponse->body();

        // Convierte el CSV a array
        $lines = explode("\n", $csv);
        $headers = str_getcsv(array_shift($lines));
        $result = [];
        foreach ($lines as $line) {
            if (trim($line) === '') continue;
            $row = str_getcsv($line);
            if (count($row) === count($headers)) {
                $result[] = array_combine($headers, $row);
            }
        }
        return response()->json($result);
    }
}