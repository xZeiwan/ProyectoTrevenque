<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

// Controlador para gestionar las peticiones relacionadas con el servicio el-tiempo.net
class TiempoNetController extends Controller {

    /**
     * Devuelve el listado de provincias desde la base de datos.
     * GET /api/provincias
     */
    public function listaProvincias()
    {
        // Consulta la tabla 'provincias' y selecciona los campos CODPROV y NOMBRE_PROVINCIA
        $provincias = DB::table('provincias')->select('CODPROV', 'NOMBRE_PROVINCIA')->get();
        // Devuelve el resultado como JSON
        return response()->json(['provincias' => $provincias]);
    }

    /**
     * Devuelve los datos meteorológicos de una provincia usando el-tiempo.net
     * GET /api/tiempo/{codprov}
     */
    public function datosProvincia($codprov)
    {
        // Construye la URL de la API externa usando el código de provincia recibido
        $url = "https://www.el-tiempo.net/api/json/v2/provincias/{$codprov}";
        // Realiza la petición HTTP a la API externa
        $response = Http::get($url);
        // Si la respuesta es exitosa, devuelve el JSON recibido
        // Si falla, devuelve un error 500
        return $response->successful()
            ? response()->json($response->json())
            : response()->json(['error' => 'Error al obtener datos de provincia'], 500);
    }

    /**
     * Devuelve el listado de municipios de una provincia, buscando por nombre de provincia.
     * GET /api/municipios/{nombreProvincia}
     */
    public function municipiosPorProvincia($nombreProvincia)
    {
        try {
            // Decodifica el nombre de provincia por si viene con caracteres codificados (ej: %C3%B3)
            $nombreProvincia = urldecode($nombreProvincia);

            // Normaliza el nombre: quita tildes, pasa a minúsculas y elimina espacios
            $normalizado = mb_strtolower(str_replace(
                ['á','é','í','ó','ú','Á','É','Í','Ó','Ú','ñ','Ñ'],
                ['a','e','i','o','u','a','e','i','o','u','n','n'],
                trim($nombreProvincia)
            ));

            // Busca la provincia en la base de datos, normalizando también los nombres de la BD
            $provincia = collect(DB::table('provincias')->get())->first(function ($p) use ($normalizado) {
                $nombre = mb_strtolower(str_replace(
                    ['á','é','í','ó','ú','Á','É','Í','Ó','Ú','ñ','Ñ'],
                    ['a','e','i','o','u','a','e','i','o','u','n','n'],
                    trim($p->NOMBRE_PROVINCIA)
                ));
                // Compara el nombre normalizado recibido con el de la BD
                return $nombre === $normalizado;
            });

            // Si no se encuentra la provincia, devuelve error 404
            if (!$provincia) {
                return response()->json(['error' => 'Provincia no encontrada'], 404);
            }

            // Consulta los municipios de esa provincia en la BD
            $municipios = DB::table('municipios')
                ->where('CODPROV', $provincia->CODPROV)
                ->select('CODPROV', 'CODIGOINE', 'NOMBRE')
                ->orderBy('NOMBRE')
                ->get();

            // Devuelve el listado de municipios como JSON
            return response()->json($municipios);

        } catch (\Throwable $e) {
            // Si ocurre cualquier error, devuelve error 500 con el mensaje
            return response()->json([
                'error' => 'Error interno del servidor',
                'detalle' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Devuelve los datos meteorológicos de un municipio usando el-tiempo.net
     * GET /api/tiempo-municipio/{codprov}/{codigoine}
     */
    public function datosMunicipio($codprov, $codigoine)
    {
        // Solo se usan los primeros 5 dígitos del código INE para la API externa
        $id = substr($codigoine, 0, 5);

        // Busca el municipio en la base de datos para obtener su nombre y otros datos
        $municipio = DB::table('municipios')
            ->where('CODIGOINE', $codigoine)
            ->first();

        // Si no se encuentra el municipio, devuelve error 404
        if (!$municipio) {
            return response()->json(['error' => 'Municipio no encontrado'], 404);
        }

        // Construye la URL de la API externa usando el código de provincia y el código INE
        $url = "https://www.el-tiempo.net/api/json/v2/provincias/{$codprov}/municipios/{$id}";

        try {
            // Realiza la petición HTTP a la API externa
            $response = Http::get($url);
            // Si la respuesta no es exitosa, devuelve error 404
            if (!$response->successful()) {
                return response()->json(['error' => 'No hay datos disponibles para este municipio'], 404);
            }

            // Obtiene los datos de la respuesta
            $data = $response->json();
            // Añade los datos del municipio de la BD al resultado
            $data['municipio'] = $municipio;
            // Devuelve el resultado como JSON
            return response()->json($data);

        } catch (\Exception $e) {
            // Si ocurre un error al conectar con la API externa, devuelve error 500
            return response()->json(['error' => 'Fallo al conectar con el-tiempo.net', 'detalle' => $e->getMessage()], 500);
        }
    }
}