<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AemetProvinciaController extends Controller
{
    /**
     * Devuelve el listado de provincias disponibles en municipiosaemet.
     */
    public function index()
    {
        $provincias = DB::table('provinciasaemet')
            ->select('CODIGO as CODPROV', 'NOMBRE')
            ->orderBy('NOMBRE')
            ->get();

        return response()->json(['provincias' => $provincias]);
    }

    /**
     * Devuelve la predicción de una provincia AEMET.
     */
    public function consultarPorCodigo($codprov)
    {
        // Verifica que la provincia exista
        $provincia = DB::table('provinciasaemet')->where('CODIGO', $codprov)->first();
        if (!$provincia) {
            return response()->json(['error' => 'Provincia no encontrada'], 404);
        }

        $apiKey = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJraWdvaXJ5dEBnbWFpbC5jb20iLCJqdGkiOiJmOGI0OTI0Ni1kY2EwLTQ5YjUtYWQ5Ny1iZDVkM2E0NmQ3ZDYiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTc0NzY1NDkyMCwidXNlcklkIjoiZjhiNDkyNDYtZGNhMC00OWI1LWFkOTctYmQ1ZDNhNDZkN2Q2Iiwicm9sZSI6IiJ9.H-5HITESkPV7-u0b3duBh7F0cB8G-WL4JTSehalYwyw';
        $url = "https://opendata.aemet.es/opendata/api/prediccion/provincia/hoy/" . urlencode($codprov) . "?api_key=" . $apiKey;

        // Paso 1: obtener URL temporal desde AEMET
        $response = Http::get($url);

        if ($response->failed()) {
            Log::error("Error al consultar AEMET provincia", ['codigo' => $codprov, 'status' => $response->status()]);
            return response()->json(['error' => 'Error consultando AEMET', 'status' => $response->status()], 500);
        }

        $json = $response->json();
        $datosUrl = $json['datos'] ?? null;

        if (!$datosUrl) {
            Log::warning("Respuesta sin URL de datos", ['codigo' => $codprov, 'respuesta' => $json]);
            return response()->json(['error' => 'Respuesta inválida de AEMET'], 500);
        }

        // Paso 2: descargar el contenido desde la URL proporcionada
        $detalles = Http::get($datosUrl);
        if ($detalles->failed()) {
            Log::error("No se pudieron obtener los datos detallados", ['url' => $datosUrl]);
            return response()->json(['error' => 'No se pudieron obtener los datos detallados de AEMET'], 500);
        }

        // Convertir a UTF-8 antes de decodificar
        $body = mb_convert_encoding($detalles->body(), 'UTF-8', 'ISO-8859-1');
        $data = json_decode($body, true);

        if ($data) {
            return response()->json($data);
        }

        // Si no es JSON, devuelve texto plano
        return response($body, 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }
}