<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class TiempoComunidadController extends Controller
{
    public function listar()
    {
        $comunidades = DB::table('comunidadautonoma')->select('CODIGO', 'NOMBRE')->get();
        return response()->json($comunidades);}

    public function tiempoComunidad($codigo)
{
    try {
        // Buscar provincias de la comunidad
        $provincias = DB::table('provincias')
            ->where('CODCOMUNIDAD', $codigo)
            ->get();

        if ($provincias->isEmpty()) {
            return response()->json(['error' => 'No hay provincias para esta comunidad'], 404);
        }

        $resultados = [];

        foreach ($provincias as $provincia) {
            $url = "https://www.el-tiempo.net/api/json/v2/provincias/{$provincia->CODPROV}";
            $response = Http::get($url);

            if ($response->successful()) {
                $resultados[] = [
                    'provincia' => $provincia->NOMBRE_PROVINCIA,
                    'datos' => $response->json()
                ];
            }
        }

        return response()->json($resultados);

    } catch (\Exception $e) {
        return response()->json([
            'error' => 'Fallo al obtener datos',
            'detalle' => $e->getMessage()
        ], 500);
    }
}
}
