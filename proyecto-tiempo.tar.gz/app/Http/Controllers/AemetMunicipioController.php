<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AemetMunicipioController extends Controller
{
    public function consultarPorCodigo($codigo)
    {
        Log::info("Consultando AEMET para el código:", ['codigo' => $codigo]);

        $apiKey = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJraWdvaXJ5dEBnbWFpbC5jb20iLCJqdGkiOiJmOGI0OTI0Ni1kY2EwLTQ5YjUtYWQ5Ny1iZDVkM2E0NmQ3ZDYiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTc0NzY1NDkyMCwidXNlcklkIjoiZjhiNDkyNDYtZGNhMC00OWI1LWFkOTctYmQ1ZDNhNDZkN2Q2Iiwicm9sZSI6IiJ9.H-5HITESkPV7-u0b3duBh7F0cB8G-WL4JTSehalYwyw';
        $urlBase = "https://opendata.aemet.es/opendata/api/prediccion/especifica/municipio/diaria/";

        // Paso 1: obtener URL temporal desde AEMET
        $response = Http::get($urlBase . urlencode($codigo) . "?api_key=" . $apiKey);

        if ($response->failed()) {
            Log::error("Error al consultar AEMET", ['codigo' => $codigo, 'status' => $response->status()]);
            return response()->json(['error' => 'Error AEMET', 'status' => $response->status()], 500);
        }

        $json = $response->json();
        $datosUrl = $json['datos'] ?? null;

        if (!$datosUrl) {
            Log::warning("Respuesta sin URL de datos", ['codigo' => $codigo, 'respuesta' => $json]);
            return response()->json(['error' => 'Respuesta inválida de AEMET'], 500);
        }

        // Paso 2: descargar el JSON desde la URL proporcionada
        $detalles = Http::get($datosUrl);
        if ($detalles->failed()) {
            Log::error("No se pudieron obtener los datos detallados", ['url' => $datosUrl]);
            return response()->json(['error' => 'No se pudieron obtener los datos detallados de AEMET'], 500);
        }

        // Convertir a UTF-8 antes de decodificar
        $body = mb_convert_encoding($detalles->body(), 'UTF-8', 'ISO-8859-1');
        $data = json_decode($body, true);
        if (!$data) {
            Log::error("JSON inválido recibido", ['body' => $body]);
            return response()->json(['error' => 'JSON inválido recibido de AEMET'], 500);
        }

        // Si es un array con al menos un objeto, extrae el primero
        if (is_array($data) && isset($data[0])) {
            $data = $data[0];
        }

        Log::info("Datos AEMET obtenidos correctamente", ['ejemplo' => $data['nombre'] ?? '']);

        return response()->json($data);
    }
}
