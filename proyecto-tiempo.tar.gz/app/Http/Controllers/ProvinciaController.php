<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProvinciaController extends Controller
{
    public function index()
    {
        try {
            $provincias = DB::table('provincias')->orderBy('NOMBRE_PROVINCIA')->get();

            return response()->json([
                'provincias' => $provincias
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'No se pudieron obtener las provincias',
                'mensaje' => $e->getMessage()
            ], 500);
        }
    }
}
