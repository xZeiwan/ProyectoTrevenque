<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class MapaController extends Controller
{
    /**
     * Devuelve todos los puntos de control de la base de datos.
     * GET /api/puntos-control
     */
    public function listarPuntos()
    {
        // Selecciona todos los puntos de la tabla 'puntocontrol'
        $puntos = DB::table('puntocontrol')
            ->select('id', 'nombre', 'latitud', 'longitud', 'provincia')
            ->get();

        return response()->json($puntos);
    }

    /**
     * Devuelve el tiempo de la provincia asociada a un punto de control.
     * GET /api/puntos-control/{id}/tiempo-provincia
     */
    public function tiempoProvinciaPunto($id)
    {
        // Busca el punto de control por ID en la tabla 'puntocontrol'
        $punto = DB::table('puntocontrol')->where('id', $id)->first();

        if (!$punto) {
            return response()->json(['error' => 'Punto de control no encontrado'], 404);
        }

        // Normaliza el nombre de la provincia del punto
        $nombreProvincia = $this->normalizarTexto($punto->provincia);

        // Busca la provincia en la tabla 'provincias' (ignorando tildes y mayúsculas)
        $provincia = collect(DB::table('provincias')->get())->first(function ($p) use ($nombreProvincia) {
            $nombre = $this->normalizarTexto($p->NOMBRE_PROVINCIA);
            return $nombre === $nombreProvincia;
        });

        if (!$provincia) {
            return response()->json(['error' => 'Provincia no encontrada para este punto'], 404);
        }

        // Llama a la API externa de el-tiempo.net usando el código de provincia
        $url = "https://www.el-tiempo.net/api/json/v2/provincias/{$provincia->CODPROV}";
        $response = Http::get($url);

        if (!$response->successful()) {
            return response()->json(['error' => 'No se pudo obtener el tiempo de la provincia'], 500);
        }

        return response()->json($response->json());
    }

    /**
     * Normaliza texto quitando tildes y pasando a minúsculas.
     */
    private function normalizarTexto($texto)
    {
        $originales = ['á','é','í','ó','ú','Á','É','Í','Ó','Ú','ñ','Ñ'];
        $modificadas = ['a','e','i','o','u','a','e','i','o','u','n','n'];
        return mb_strtolower(str_replace($originales, $modificadas, trim($texto)));
    }
}