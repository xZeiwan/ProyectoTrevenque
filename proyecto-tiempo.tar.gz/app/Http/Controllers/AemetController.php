<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AemetController extends Controller
{
    public function consultarPorCodigo($codigo)
{
    // Llamada a AEMET con el endpoint correcto
    $response = Http::withHeaders([
        'api_key' => env('eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJraWdvaXJ5dEBnbWFpbC5jb20iLCJqdGkiOiJmOGI0OTI0Ni1kY2EwLTQ5YjUtYWQ5Ny1iZDVkM2E0NmQ3ZDYiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTc0NzY1NDkyMCwidXNlcklkIjoiZjhiNDkyNDYtZGNhMC00OWI1LWFkOTctYmQ1ZDNhNDZkN2Q2Iiwicm9sZSI6IiJ9.H-5HITESkPV7-u0b3duBh7F0cB8G-WL4JTSehalYwyw'),
    ])->get("https://opendata.aemet.es/opendata/api/prediccion/provincia/hoy/" . urlencode($codigo));

    if ($response->failed()) {
        return response()->json([
            'error' => 'Error al consultar la API de AEMET',
            'codigo' => $codigo,
            'estado' => $response->status(),
            'respuesta' => $response->body()
        ], 500);
    }

    // Obtener URL de datos JSON
    $datosUrl = $response->json()['datos'] ?? null;

    if (!$datosUrl) {
        return response()->json(['error' => 'Respuesta inválida de AEMET (sin datos)'], 500);
    }

    // Descargar los datos reales desde esa URL
    $datosResponse = Http::get($datosUrl);

    if ($datosResponse->failed()) {
        return response()->json(['error' => 'No se pudieron obtener los datos detallados de AEMET'], 500);
    }

    $datos = json_decode($datosResponse->body(), true);

    return response()->json($datos);
}

}
