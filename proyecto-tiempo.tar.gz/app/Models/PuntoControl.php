<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PuntoControl extends Model
{
    protected $table = 'puntocontrol'; // usa el nombre exacto de tu tabla
    public $timestamps = false; // si no usas created_at / updated_at

    protected $fillable = [
        'nombre',
        'latitud',
        'longitud',
        'provincia'
    ];
}

