<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Provinciasaemet extends Model
{
    protected $table = 'provinciasaemet';
    public $timestamps = false;

    // Si tus campos primarios no son "id", puedes especificarlos aquí:
    // protected $primaryKey = 'codigo'; 
}
