// Base de la API para las peticiones a tu backend Laravel
const aemetApiBase = 'http://192.168.56.101:8000/api';

// ==================== PROVINCIAS ====================

// Carga el listado de provincias AEMET en el <select> correspondiente
async function cargarProvinciasAemet() {
  try {
    // Petición a la API para obtener las provincias
    const res = await fetch(`${aemetApiBase}/aemet/provincias`);
    const data = await res.json();

    // Selecciona el elemento <select> donde se mostrarán las provincias
    const select = document.getElementById('provinciaAemetSelect');
    if (!select) return;

    // Limpia el select y añade la opción por defecto
    select.innerHTML = '<option value="">Seleccione provincia</option>';
    // Añade cada provincia como opción en el select
    data.provincias.forEach(p => {
      const option = document.createElement('option');
      option.value = p.CODPROV;
      option.text = p.NOMBRE;
      select.appendChild(option);
    });
  } catch (err) {
    // Si hay error en la petición, lo muestra por consola
    console.error("Error cargando provincias AEMET:", err);
  }
}

// Busca y muestra la predicción de una provincia AEMET (puede ser JSON o texto plano)
async function buscarProvinciaAemet() {
  // Obtiene el código de provincia seleccionado
  const select = document.getElementById('provinciaAemetSelect');
  const codprov = select.value;
  if (!codprov) return;

  // Elemento donde se mostrará el resultado
  const div = document.getElementById('resultadoProvinciaAemet');
  div.innerHTML = '<p>Cargando datos de la provincia...</p>';

  try {
    // Petición a la API para obtener la predicción de la provincia
    const res = await fetch(`${aemetApiBase}/aemet/provincia/${codprov}`);
    const contentType = res.headers.get("content-type");

    // Si la respuesta es JSON (predicción por municipios)
    if (contentType && contentType.includes("application/json")) {
      const data = await res.json();

      // Si hay error en la respuesta, lo muestra
      if (data.error) {
        div.innerHTML = `<p style="color:red;">${data.error}</p>`;
        return;
      }

      // Si no hay datos, lo indica
      if (!Array.isArray(data) || data.length === 0) {
        div.innerHTML = `<p style="color:red;">No hay datos para esta provincia.</p>`;
        return;
      }

      // Muestra la predicción de cada municipio de la provincia
      div.innerHTML = `<h3>Predicción para municipios de la provincia</h3>`;
      data.forEach(item => {
        div.innerHTML += `
          <div class="prediccion-dia" style="border:1px solid #ccc; padding:10px; margin:10px 0; border-radius:8px;">
            <h4>${item.municipio.NOMBRE}</h4>
            <p><strong>Descripción:</strong> ${item.datos?.prediccion?.dia?.[0]?.estadoCielo?.[0]?.descripcion ?? 'No disponible'}</p>
            <p><strong>Temp. Máxima:</strong> ${item.datos?.prediccion?.dia?.[0]?.temperatura?.maxima ?? 'N/A'}°C</p>
            <p><strong>Temp. Mínima:</strong> ${item.datos?.prediccion?.dia?.[0]?.temperatura?.minima ?? 'N/A'}°C</p>
          </div>
        `;
      });
    } else {
      // Si la respuesta es texto plano (predicción provincial)
      const texto = await res.text();
      let lineas = texto.split('\n');

      // Filtrar líneas no deseadas (cabeceras, etc.)
      lineas = lineas.filter(linea =>
        !linea.startsWith('AGENCIA ESTATAL DE METEOROLOGÍA') &&
        !linea.startsWith('PREDICCIÓN PARA LA PROVINCIA') &&
        !linea.startsWith('PREDICCIÓN VÁLIDA')
      );

      // Unir el texto y normalizar espacios
      const textoPersonalizado = lineas.join(' ').replace(/\s+/g, ' ').trim();

      // Extraer secciones: fecha (hasta "HORA OFICIAL"), ciudad y el resto
      const fechaMatch = textoPersonalizado.match(/^(DÍA.*?HORA OFICIAL)/);
      const fecha = fechaMatch ? fechaMatch[1] : '';
      let resto = textoPersonalizado.replace(fecha, '').trim();

      // Extraer ciudad (mayúsculas al principio)
      const ciudadMatch = resto.match(/^([A-ZÁÉÍÓÚÑ ]+)\s/);
      const ciudad = ciudadMatch ? ciudadMatch[1].trim() : '';
      resto = resto.replace(ciudad, '').trim();

      // Separa el bloque de temperaturas del resto del contenido
      const tempTitulo = 'TEMPERATURAS MÍNIMAS Y MÁXIMAS PREVISTAS (°C):';
      const tempIndex = resto.indexOf(tempTitulo);
      let info = '';
      let temps = '';
      if (tempIndex !== -1) {
        info = resto.substring(0, tempIndex).trim();
        temps = resto.substring(tempIndex + tempTitulo.length).trim();
      } else {
        info = resto;
      }

      // Procesa el bloque de temperaturas para mostrarlo bonito
      let tempsHTML = '';
      if (temps) {
        // Suponemos que el bloque de temperaturas tiene la estructura: "Ciudad MinTemp MaxTemp" repetido
        const tokens = temps.split(/\s+/);
        for (let i = 0; i < tokens.length - 2; i += 3) {
          const ciudadTemp = tokens[i];
          const minima = tokens[i + 1];
          const maxima = tokens[i + 2];
          tempsHTML += `
            <div style="display: flex; justify-content: center; padding: 4px 0; border-bottom: 1px dotted #ccc;">
              <div style="width: 50%; text-align: center;"><strong>${ciudadTemp}</strong></div>
              <div style="width: 50%; text-align: center;">${minima}°C / ${maxima}°C</div>
            </div>
          `;
        }
      }

      // Mostrar la predicción provincial estructurada: fecha, ciudad, info y temperaturas
      div.innerHTML = `
        <div style="max-width:800px; margin: 0 auto; text-align: center; font-size: 1.2em; box-shadow: 2px 2px 8px #666; padding: 10px; border: 1px solid #ccc; border-radius: 8px; background: #f9f9f9;">
          ${fecha ? `<div style="margin-bottom: 10px;"><strong>${fecha}</strong></div>` : ''}
          ${(ciudad || info) ? `
            <div style="margin-bottom: 10px;">
              ${ciudad ? `<div><strong>${ciudad}</strong></div>` : ''}
              ${info ? `<div>${info}</div>` : ''}
            </div>
          ` : ''}
          ${tempsHTML ? `
            <div style="margin-bottom: 10px;"><strong>${tempTitulo}</strong></div>
            <div>${tempsHTML}</div>
          ` : ''}
        </div>
      `;
    }
  } catch (err) {
    // Si hay error en la petición, lo muestra
    div.innerHTML = `<p style="color:red;">Error al consultar la provincia en AEMET.</p>`;
    console.error("Error al buscar provincia AEMET:", err);
  }
}

// ==================== MUNICIPIOS ====================

// Carga el listado de municipios AEMET en el <select> correspondiente
async function cargarMunicipiosAemet() {
  try {
    // Petición a la API para obtener los municipios
    const res = await fetch(`${aemetApiBase}/municipios-aemet`);
    const data = await res.json();

    // Selecciona el elemento <select> donde se mostrarán los municipios
    const select = document.getElementById('municipiosAemetSelect');
    if (!select) return;

    // Añade cada municipio como opción en el select
    data.forEach(m => {
      if (!m.codigo || !/^\d{5}$/.test(m.codigo)) return;

      const option = document.createElement('option');
      option.value = m.codigo;
      option.text = m.NOMBRE;
      select.appendChild(option);
    });
  } catch (err) {
    // Si hay error en la petición, lo muestra por consola
    console.error("Error cargando municipios AEMET:", err);
  }
}

// Busca y muestra la predicción de un municipio AEMET
async function buscarMunicipioAemet() {
  // Obtiene el código del municipio seleccionado
  let codigo = document.getElementById('municipiosAemetSelect').value;
  codigo = codigo.trim();

  // Valida el código del municipio
  if (!/^\d{5}$/.test(codigo)) {
    console.error("Código de municipio inválido:", codigo);
    return;
  }

  try {
    // Petición a la API para obtener la predicción del municipio
    const res = await fetch(`${aemetApiBase}/aemet/municipio/${codigo}`);
    const datos = await res.json();

    // Elemento donde se mostrará el resultado
    const contenedor = document.getElementById('resultadoMunicipioAemet');
    contenedor.innerHTML = ''; // Limpiar contenido previo

    // Verificar predicción disponible
    const dias = datos?.prediccion?.dia;
    if (!Array.isArray(dias)) {
      contenedor.innerHTML = `<p style="color:red;">No se encontraron datos para este municipio.</p>`;
      return;
    }

    // Mostrar cabecera
    contenedor.innerHTML += `<h3>Predicción para ${datos.nombre} (${datos.provincia})</h3>`;

    // Mostrar cada día de predicción
    dias.forEach(d => {
      contenedor.innerHTML += `
        <div class="prediccion-dia" style="border:1px solid #ccc; padding:10px; margin:10px 0; border-radius:8px;">
          <h4>${d.fecha}</h4>
          <p><strong>Temperatura:</strong> ${d.temperatura.minima}°C / ${d.temperatura.maxima}°C</p>
          <p><strong>Estado del cielo:</strong> ${d.estadoCielo[0]?.descripcion ?? 'No disponible'}</p>
          <p><strong>Viento:</strong> ${d.viento[0]?.direccion ?? '?'} ${d.viento[0]?.velocidad ?? '?'} km/h</p>
          <p><strong>Humedad:</strong> ${d.humedadRelativa.minima}% - ${d.humedadRelativa.maxima}%</p>
        </div>
      `;
    });
  } catch (err) {
    // Si hay error en la petición, lo muestra por consola
    console.error("Error al buscar predicción AEMET:", err);
  }
}

// ==================== COMUNIDADES ====================

// Carga el listado de comunidades autónomas desde la API de AEMET y las añade al <select> correspondiente
async function cargarComunidadesAemet() {
  try {
    // Petición a la API para obtener las comunidades
    const res = await fetch(`${aemetApiBase}/aemet/comunidades`);
    const data = await res.json();

    // Selecciona el elemento <select> donde se mostrarán las comunidades
    const select = document.getElementById('comunidadAemetSelect');
    if (!select) return;

    // Limpia el select y añade la opción por defecto
    select.innerHTML = '<option value="">Seleccione comunidad</option>';

    // Añade cada comunidad como opción en el select
    data.forEach(c => {
      const option = document.createElement('option');
      option.value = c.codigo;
      option.text = c.nombre;
      select.appendChild(option);
    });
  } catch (err) {
    // Si hay error en la petición, lo muestra por consola
    console.error("Error cargando comunidades AEMET:", err);
  }
}

// Busca y muestra la predicción para todas las provincias de una comunidad seleccionada
async function buscarComunidadAemet() {
  // Obtiene el código de la comunidad seleccionada
  const select = document.getElementById('comunidadAemetSelect');
  const codigo = select.value;
  const div = document.getElementById('resultadoComunidadAemet');
  div.innerHTML = 'Cargando...';

  // Si no hay comunidad seleccionada, limpia el resultado y sale
  if (!codigo) {
    div.innerHTML = '';
    return;
  }

  try {
    // Pide a la API el listado de provincias de la comunidad seleccionada
    const res = await fetch(`${aemetApiBase}/aemet/comunidad/${codigo}/provincias`);
    const provincias = await res.json();

    // Si hay error en la respuesta, lo muestra
    if (provincias.error) {
      div.innerHTML = `<p style="color:red;">${provincias.error}</p>`;
      return;
    }
    // Si no hay provincias, lo indica
    if (!Array.isArray(provincias) || provincias.length === 0) {
      div.innerHTML = `<p>No hay provincias para esta comunidad.</p>`;
      return;
    }

    // Prepara el contenedor para mostrar las provincias y sus predicciones
    div.innerHTML = `<h4>Provincias:</h4><div id="provinciasTiempo"></div>`;
    const provinciasTiempoDiv = document.getElementById('provinciasTiempo');

    // Para cada provincia, pide la predicción y la muestra
    for (const provincia of provincias) {
      // Crea un div para mostrar la predicción de la provincia
      const provDiv = document.createElement('div');
      provDiv.innerHTML = `<h5>${provincia.nombre}</h5><div>Cargando predicción...</div>`;
      provinciasTiempoDiv.appendChild(provDiv);

      try {
        // Pide la predicción de la provincia a la API
        const resProv = await fetch(`${aemetApiBase}/aemet/provincia/${provincia.codigo}`);
        const contentType = resProv.headers.get("content-type");

        // Si la respuesta es JSON, la procesa como predicción por municipios
        if (contentType && contentType.includes("application/json")) {
          const data = await resProv.json();
          if (data.error) {
            provDiv.innerHTML = `<h5>${provincia.nombre}</h5><p style="color:red;">${data.error}</p>`;
            continue;
          }
          if (!Array.isArray(data) || data.length === 0) {
            provDiv.innerHTML = `<h5>${provincia.nombre}</h5><p>No hay datos para esta provincia.</p>`;
            continue;
          }
          // Muestra la predicción de cada municipio de la provincia
          let html = '';
          data.forEach(item => {
            html += `
              <div class="prediccion-dia" style="border:1px solid #ccc; padding:10px; margin:10px 0; border-radius:8px;">
                <h6>${item.municipio.NOMBRE}</h6>
                <p><strong>Descripción:</strong> ${item.datos?.prediccion?.dia?.[0]?.estadoCielo?.[0]?.descripcion ?? 'No disponible'}</p>
                <p><strong>Temp. Máxima:</strong> ${item.datos?.prediccion?.dia?.[0]?.temperatura?.maxima ?? 'N/A'}°C</p>
                <p><strong>Temp. Mínima:</strong> ${item.datos?.prediccion?.dia?.[0]?.temperatura?.minima ?? 'N/A'}°C</p>
              </div>
            `;
          });
          provDiv.innerHTML = `<h5>${provincia.nombre}</h5>${html}`;
        } else {
          // Si la respuesta es texto plano, la procesa y muestra de forma estructurada
          const texto = await resProv.text();
          let lineas = texto.split('\n');

          // Filtra las líneas que no se quieren mostrar (cabeceras, etc.)
          lineas = lineas.filter(linea =>
            !linea.startsWith('AGENCIA ESTATAL DE METEOROLOGÍA') &&
            !linea.startsWith('PREDICCIÓN PARA LA PROVINCIA') &&
            !linea.startsWith('PREDICCIÓN VÁLIDA')
          );

          // Une el texto y normaliza los espacios
          const textoPersonalizado = lineas.join(' ').replace(/\s+/g, ' ').trim();

          // Extrae la fecha (hasta "HORA OFICIAL"), la ciudad y el resto del texto
          const fechaMatch = textoPersonalizado.match(/^(DÍA.*?HORA OFICIAL)/);
          const fecha = fechaMatch ? fechaMatch[1] : '';
          let resto = textoPersonalizado.replace(fecha, '').trim();

          const ciudadMatch = resto.match(/^([A-ZÁÉÍÓÚÑ ]+)\s/);
          const ciudad = ciudadMatch ? ciudadMatch[1].trim() : '';
          resto = resto.replace(ciudad, '').trim();

          // Separa el bloque de temperaturas del resto del contenido
          const tempTitulo = 'TEMPERATURAS MÍNIMAS Y MÁXIMAS PREVISTAS (°C):';
          const tempIndex = resto.indexOf(tempTitulo);
          let info = '';
          let temps = '';
          if (tempIndex !== -1) {
            info = resto.substring(0, tempIndex).trim();
            temps = resto.substring(tempIndex + tempTitulo.length).trim();
          } else {
            info = resto;
          }

          // Procesa el bloque de temperaturas para mostrarlo bonito
          let tempsHTML = '';
          if (temps) {
            // Busca patrones de "Ciudad Min Max" y los muestra en filas
            const regex = /([^\d]+?)\s+(\d{1,2})\s+(\d{1,2})(?=\s|$)/g;
            let match;
            let bloques = [];
            while ((match = regex.exec(temps)) !== null) {
              const nombre = match[1].trim();
              const min = match[2];
              const max = match[3];
              bloques.push(`
                <div style="display: flex; justify-content: center; align-items: center; padding: 4px 0; border-bottom: 1px dotted #ccc;">
                  <div style="width: 60%; text-align: left; font-weight: bold; color: #222;">${nombre}</div>
                  <div style="width: 40%; text-align: right; font-weight: bold; color: #222;">${min}°C / ${max}°C</div>
                </div>
              `);
            }
            // Si no se detectó ningún bloque, muestra el texto tal cual
            if (bloques.length === 0) {
              tempsHTML = `<div style="text-align:left; font-weight:bold; color:#222;">${temps.replace(/\s+/g, ' ')}</div>`;
            } else {
              tempsHTML = bloques.join('');
            }
          }

          // Muestra la predicción provincial estructurada: fecha, ciudad, info y temperaturas
          provDiv.innerHTML = `
          <div style="max-width:700px; margin: 10px auto; text-align: center; font-size: 1em; box-shadow: 2px 2px 8px #666; padding: 10px; border: 1px solid #ccc; border-radius: 8px; background: #f9f9f9;">
            ${fecha ? `<div style="margin-bottom: 10px;"><strong>${fecha}</strong></div>` : ''}
            ${(ciudad || info) ? `
              <div style="margin-bottom: 10px;">
                ${ciudad ? `<div><strong>${ciudad}</strong></div>` : ''}
                ${info ? `<div>${info}</div>` : ''}
              </div>
            ` : ''}
            ${tempsHTML ? `
              <div style="margin-bottom: 10px;"><strong>${tempTitulo}</strong></div>
              <div>${tempsHTML}</div>
            ` : ''}
          </div>
        `;
        }
      } catch (err) {
        // Si hay error al consultar la predicción de la provincia, lo muestra
        provDiv.innerHTML = `<h5>${provincia.nombre}</h5><p style="color:red;">Error al consultar el tiempo.</p>`;
      }
    }
  } catch (err) {
    // Si hay error general al consultar la comunidad, lo muestra
    div.innerHTML = `<p style="color:red;">Error al consultar la comunidad en AEMET.</p>`;
    console.error("Error al buscar comunidad AEMET:", err);
  }
}

// ==================== INICIALIZACIÓN ====================

// Al cargar la página, carga provincias, municipios y comunidades
document.addEventListener('DOMContentLoaded', () => {
  cargarProvinciasAemet();
  cargarMunicipiosAemet();
  cargarComunidadesAemet();
});