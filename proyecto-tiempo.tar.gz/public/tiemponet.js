
console.log("tiemponet.js cargado"); // Base de la API para las peticiones a tu backend Laravel
const apiBase = 'http://192.168.56.101:8000/api';

// Variable global para almacenar el listado de provincias cargadas
let listaProvincias = [];

/**
 * Normaliza un texto eliminando acentos y convirtiendo a minúsculas.
 * Útil para comparar nombres de provincias o municipios.
 */
function normalizarTexto(texto) {
  return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

/**
 * Carga el listado de provincias desde la API y las añade al <select> correspondiente.
 * Guarda el listado en la variable global listaProvincias.
 */
async function cargarProvincias() {
  console.log("cargarProvincias llamada");
  try {
    const res = await fetch(`${apiBase}/provincias`);
    const data = await res.json();
    console.log(data);
    listaProvincias = data.provincias;

    const select = document.getElementById('provinciaSelect');
    // Añade cada provincia como opción en el select
    listaProvincias.forEach(p => {
      const option = new Option(p.NOMBRE_PROVINCIA, p.NOMBRE_PROVINCIA);
      select.appendChild(option);
    });
  } catch (err) {
    alert("No se pudieron cargar las provincias");
  }
}

/**
 * Carga el listado de municipios de la provincia seleccionada y los añade al <select> correspondiente.
 * Se ejecuta cuando el usuario selecciona una provincia.
 */
async function cargarMunicipiosDesdeSelect() {
  const valor = document.getElementById('provinciaSelect').value;
  const provincia = listaProvincias.find(p => p.NOMBRE_PROVINCIA === valor);
  if (!provincia) return;

  try {
    const res = await fetch(`${apiBase}/municipios/${provincia.NOMBRE_PROVINCIA}`);
    const municipios = await res.json();

    const select = document.getElementById('municipiosSelect');
    select.innerHTML = '<option value="">Elige un municipio</option>';
    // Añade cada municipio como opción en el select
    municipios.forEach(m => {
      const option = new Option(m.NOMBRE, `${m.CODPROV}-${m.CODIGOINE}`);
      select.appendChild(option);
    });
  } catch {
    alert("Error cargando municipios");
  }
}

/**
 * Busca y muestra la predicción meteorológica de la provincia seleccionada.
 * Llama a la API y muestra los datos en el div correspondiente.
 */
async function buscarProvincia() {
  const valor = document.getElementById('provinciaSelect').value;
  const provincia = listaProvincias.find(p => p.NOMBRE_PROVINCIA === valor);
  if (!provincia) return;

  try {
    const response = await fetch(`${apiBase}/tiempo/${provincia.CODPROV}`);
    const data = await response.json();
    mostrarProvincia(data);
  } catch {
    alert("Error consultando la provincia");
  }
}

/**
 * Muestra en pantalla la predicción meteorológica de la provincia recibida.
 * Busca la capital de la provincia y muestra su información.
 */
function mostrarProvincia(data) {
  const ciudad = data.ciudades?.find(c => c.name === data.provincia?.CAPITAL_PROVINCIA);
  const div = document.getElementById('resultadoProvincia');
  if (!ciudad) {
    div.innerHTML = `<p style="color:red;">No se encontraron datos</p>`;
    return;
  }

  div.innerHTML = `
    <h2>Tiempo en ${ciudad.name} (provincia de ${data.provincia.NOMBRE_PROVINCIA})</h2>
    <p><strong>Descripción:</strong> ${ciudad.stateSky?.description || 'No disponible'}</p>
    <p><strong>Temp. Máxima:</strong> ${ciudad.temperatures?.max ?? 'N/A'}°C</p>
    <p><strong>Temp. Mínima:</strong> ${ciudad.temperatures?.min ?? 'N/A'}°C</p>
  `;
}

/**
 * Busca y muestra la predicción meteorológica del municipio seleccionado.
 * Llama a la API y muestra los datos en el div correspondiente.
 */
async function buscarMunicipio() {
  const valor = document.getElementById('municipiosSelect').value;
  if (!valor) return;
  const [codprov, codigoine] = valor.split('-');

  try {
    const response = await fetch(`${apiBase}/tiempo-municipio/${codprov}/${codigoine}`);
    const data = await response.json();

    if (data.error) {
      document.getElementById('resultadoMunicipio').innerHTML = `<p style="color:red;">${data.error}</p>`;
      return;
    }

    mostrarMunicipio(data);
  } catch {
    alert("Error consultando el municipio");
  }
}

/**
 * Muestra en pantalla la predicción meteorológica del municipio recibido.
 */
function mostrarMunicipio(data) {
  const div = document.getElementById('resultadoMunicipio');
  div.innerHTML = `
    <h2>Tiempo en ${data.municipio.NOMBRE}</h2>
    <p><strong>Descripción:</strong> ${data.stateSky?.description || 'No disponible'}</p>
    <p><strong>Temperatura:</strong> ${data.temperatura_actual ?? 'N/A'}°C</p>
    <p><strong>Humedad:</strong> ${data.humedad ?? 'N/A'}%</p>
    <p><strong>Viento:</strong> ${data.viento ?? 'N/A'} km/h</p>
  `;
}

/**
 * Carga el listado de comunidades autónomas desde la API y las añade al <select> correspondiente.
 */
async function cargarComunidades() {
  try {
    const res = await fetch(`${apiBase}/comunidades`);
    const comunidades = await res.json();

    const select = document.getElementById('comunidadSelect');
    // Añade cada comunidad como opción en el select
    comunidades.forEach(c => {
      const option = new Option(c.NOMBRE, c.CODIGO);
      select.appendChild(option);
    });
  } catch {
    alert("No se pudieron cargar las comunidades");
  }
}

/**
 * Busca y muestra la predicción meteorológica para todas las provincias de la comunidad seleccionada.
 * Llama a la API y muestra los datos en el div correspondiente.
 */
async function buscarComunidad() {
  const codigo = document.getElementById('comunidadSelect').value;
  if (!codigo) return;

  try {
    const response = await fetch(`${apiBase}/tiempo-comunidad/${codigo}`);
    const data = await response.json();

    if (data.error) {
      document.getElementById('resultadoComunidad').innerHTML = `<p style="color:red;">${data.error}</p>`;
      return;
    }

    mostrarProvinciasDeComunidad(data);
  } catch {
    alert("Error consultando la comunidad");
  }
}

/**
 * Muestra en pantalla la predicción meteorológica de todas las provincias de una comunidad.
 * Para cada provincia, muestra la información de su capital.
 */
function mostrarProvinciasDeComunidad(provincias) {
  const div = document.getElementById('resultadoComunidad');
  div.innerHTML = `<h3>Predicción por provincias</h3>`;

  provincias.forEach(p => {
    // Busca la capital de la provincia
    const ciudad = p.datos.ciudades?.find(c => c.name === p.datos.provincia?.CAPITAL_PROVINCIA);

    const html = `
      <div class="prediccion-dia">
        <h4>${p.provincia}</h4>
        <p><strong>Capital:</strong> ${ciudad?.name || 'Desconocido'}</p>
        <p><strong>Descripción:</strong> ${ciudad?.stateSky?.description || 'No disponible'}</p>
        <p><strong>Temp. Máxima:</strong> ${ciudad?.temperatures?.max ?? 'N/A'}°C</p>
        <p><strong>Temp. Mínima:</strong> ${ciudad?.temperatures?.min ?? 'N/A'}°C</p>
      </div>
    `;

    div.innerHTML += html;
  });
}

/**
 * Al cargar la página, carga provincias y comunidades.
 * (No carga municipios hasta que se seleccione una provincia)
 */
document.addEventListener('DOMContentLoaded', async () => {
  console.log("DOMContentLoaded disparado");
  await cargarProvincias();
  await cargarComunidades();
});