window.onload = async () => {
  // Inicializa el mapa centrado en España
  const map = L.map("map").setView([40.4168, -3.7038], 6);

  // Añade la capa base de OpenStreetMap
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution:
      'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
  }).addTo(map);

  try {
    // 1. Obtener todos los puntos de control de tu base de datos
    const res = await fetch("http://192.168.56.101:8000/api/puntos-control");
    const puntos = await res.json();

    // Recorre cada punto de control recibido
    puntos.forEach((punto) => {
      // Convierte latitud y longitud a número
      const lat = Number(punto.latitud);
      const lng = Number(punto.longitud);

      // Si no son válidos, ignora este punto
      if (isNaN(lat) || isNaN(lng)) return;

      // Crea un marcador en el mapa para cada punto
      const marker = L.marker([lat, lng]).addTo(map);

      // Al hacer clic en el marcador, muestra el tiempo de la ciudad/provincia asociada
      marker.on("click", async () => {
        try {
          // Llama a tu backend para obtener el tiempo de la provincia asociada al punto
          const resTiempo = await fetch(`http://192.168.56.101:8000/api/puntos-control/${punto.id}/tiempo-provincia`);
          if (!resTiempo.ok) {
            // Si la respuesta no es correcta, muestra error en el popup
            marker.bindPopup(`<strong>${punto.nombre}</strong><br><em>No se pudo obtener el tiempo (${resTiempo.status})</em>`).openPopup();
            return;
          }
          // Parsea la respuesta como JSON
          const datos = await resTiempo.json();

          // Busca la capital de la provincia en el array de ciudades (igual que en tiemponet.js)
          const capital = datos.ciudades?.find(
            c => c.name === datos.provincia?.CAPITAL_PROVINCIA
          );

          // Construye el contenido del popup
          let popupContent = `<strong>${punto.provincia}</strong><br>`;
          if (capital) {
            popupContent += `
              <strong>Capital:</strong> ${capital.name}<br>
              <strong>Descripción:</strong> ${capital.stateSky?.description || 'No disponible'}<br>
              <strong>Temp. Máxima:</strong> ${capital.temperatures?.max ?? 'N/A'}°C<br>
              <strong>Temp. Mínima:</strong> ${capital.temperatures?.min ?? 'N/A'}°C
            `;
          } else {
            popupContent += `<em>No se encontraron datos de la capital</em>`;
          }

          // Muestra el popup en el marcador
          marker.bindPopup(popupContent).openPopup();
        } catch (err) {
          // Si ocurre un error, muestra mensaje de error en el popup
          marker.bindPopup(`<strong>${punto.nombre}</strong><br><em>Error al cargar el tiempo</em>`).openPopup();
        }
      });
    });
  } catch (err) {
    // Si ocurre un error al cargar los puntos de control, lo muestra en consola
    console.error("Error cargando puntos de control:", err);
  }
};